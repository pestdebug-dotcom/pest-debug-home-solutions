PEST DEBUG WEBSITE — TWO-SECTION OPENING

1. Open index.html. This is the new opening page with two clear entry cards.
2. Pest Debug Services opens services.html: the existing construction/business content, including pre-construction soil poisoning, service descriptions, contact details and the soil-treatment advert.
3. Pest Debug Home Solutions opens home-solutions.html: household guide catalogue, prices, WhatsApp ordering and mobile-money payment details.

The original Pest Debug mosquito logo file is retained in assets/pest-debug-logo.jpg. Existing graphics and pest category SVG watermarks are retained. All pages are linked locally and are ready for static hosting such as Netlify.

IMPORTANT: Upload the CONTENTS of this folder (index.html, services.html, home-solutions.html, assets folder and README) as one site. Do not upload only an individual HTML file. The opening page must be index.html at the site root.


IMAGE COMPATIBILITY UPDATE (17 Nov 2026):
The four pest-card illustrations (cockroach, rodents, bedbug and termites) are included as local PNG files in assets/ and referenced locally by both service pages. No external image host or hotlinked image permission is required. The original Pest Debug mosquito logo file (assets/pest-debug-logo.jpg) is retained unchanged.
